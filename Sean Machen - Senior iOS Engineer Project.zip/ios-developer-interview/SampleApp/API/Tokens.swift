//
//  Tokens.swift
//  SampleApp
//
//  Created by natehancock on 6/28/22.
//

import Foundation

struct Tokens {
    static let apiKeyDict = "0b15979d-724f-4686-8686-dedb9983df50"
    static let apiKeyThes = "59a05a64-94df-4983-a3b0-a691ea99fcdb"
}
